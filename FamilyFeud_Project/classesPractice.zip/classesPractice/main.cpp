#include <iostream>
#include "rectangle.h"

using namespace std;

int main()
{

    rectangle rect1;

    return 0;
}
