#include <iostream>
#include "rectangle.h"

using namespace std;

rectangle::rectangle()
{
    cout<<"rectangle object created"<<endl;//ctor
}

/*rectangle::~rectangle()
{
    //dtor
}
*/
