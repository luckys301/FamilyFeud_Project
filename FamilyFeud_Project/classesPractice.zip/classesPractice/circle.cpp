#include "circle.h"

circle::circle(double pi, int rad)
{
    //ctor
}

circle::~circle()
{
    //dtor
}
