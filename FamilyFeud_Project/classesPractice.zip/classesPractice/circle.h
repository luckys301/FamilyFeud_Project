#ifndef CIRCLE_H
#define CIRCLE_H


class circle
{
    public:
        circle(double pi, int rad);
        virtual ~circle();

    protected:

    private:
};

#endif // CIRCLE_H
