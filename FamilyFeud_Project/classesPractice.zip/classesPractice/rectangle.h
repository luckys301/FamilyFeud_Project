#ifndef RECTANGLE_H
#define RECTANGLE_H


class rectangle
{
    public:
        rectangle();
        //virtual ~rectangle();

    protected:

    private:
};

#endif // RECTANGLE_H
