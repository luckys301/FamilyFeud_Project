#include "triangle.h"

triangle::triangle(int b, int h)
{
    //ctor
}

triangle::~triangle()
{
    //dtor
}
