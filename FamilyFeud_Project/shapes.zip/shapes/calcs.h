#ifndef CALCS_H_INCLUDED
#define CALCS_H_INCLUDED


int RectArea(int, int);
double CircleArea(double, int);
int TriArea(int, int);



#endif // CALCS_H_INCLUDED
