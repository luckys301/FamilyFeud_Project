#ifndef DISPLAY_H_INCLUDED
#define DISPLAY_H_INCLUDED


void display (int, double, int);

#endif // DISPLAY_H_INCLUDED
