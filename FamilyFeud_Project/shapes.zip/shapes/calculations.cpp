#include <iostream>


int RectArea(int length, int width)
{
    return length * width;
}

double CircleArea(double pi, int r)
{
    return pi * r * r;
}

int TriArea(int b, int h)
{
    return (b*h)/2;
}
