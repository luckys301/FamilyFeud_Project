#include <iostream>
using namespace std;

void display (int rect, double circle, int tri)
{
    cout << "The Area of the rectangle is " << rect << endl;
    cout << "The Area of the circle is " << circle << endl;
    cout << "The Area of the triangle is " << tri << endl;
}
